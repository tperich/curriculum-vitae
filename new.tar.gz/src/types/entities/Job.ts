import { BaseSectionItem } from "./BaseSectionItem";

export interface Job extends BaseSectionItem {
  position: string;
  company: string;
}
