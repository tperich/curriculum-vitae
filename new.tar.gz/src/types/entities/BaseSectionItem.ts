export interface BaseSectionItem {
  title: string;
  startedAt?: string;
  endedAt: string;
  current: boolean;
  address: string;
}
