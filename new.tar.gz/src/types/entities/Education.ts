import { BaseSectionItem } from "./BaseSectionItem";

export interface Education extends BaseSectionItem {}
