export const API = {
  BASE_URL: process.env.REACT_APP_BASE_URL,
  API_PORT: process.env.REACT_APP_API_PORT,
};
