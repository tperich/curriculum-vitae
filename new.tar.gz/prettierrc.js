module.exports = {
  bracketSpacing: true,
  singleQuote: false,
  jsxSingleQuote: false,
  arrowParens: "avoid",
  trailingComma: "all",
  printWidth: 120,
  tabWidth: 2,
  tabs: false,
  semi: true,
};
